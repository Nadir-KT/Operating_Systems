=====================================================
Read Me File for RENESAS GRAPHICS LIBRARY for RH850/D1M ETS Board
=====================================================
Updated:    08-Jul-2022 [US] - Support for ETS board.

========
Contents
========

  1. General Information 
  2. Release History
  3. Latest Changes
  4. Known Limitations
  5. Additional Info


======================
1. General Information 
======================

1.1 The RGL for D1Mx package for ETS is delivered as a Windows-Installer and patch file. 
	This directory contains this README.txt file, the RGL installer for one development environment and the patch file for supporting ETS boad.

1.2 To install the Renesas Graphic Library for D1Mx for the development environment of your choice please refer to the following file:
    RTM7RHD1M0ZGR00Q02JFZ0E_2_1_0a/RTM7RHD1M0ZGR00Q02JFZ0E/readme_rgl.txt
       
1.3 To apply the patch file for supporting ETS boad to the Renesas Graphic Library for D1Mx for the development environment.
	a. Overwrite "Patch/vlib" to the Renesas Graphic Library for D1Mx for the development environment.

1.4 There are three demo programs inside the RGL which can be found in:
	rgl_ghs_D1Mx_[obj|src]_Vxxx/vlib/app/gfx_apps/simple_draw
    
    simple_draw:
    - This application first decodes a JPEG file and then uses a Drw2D renderloop 
      to draw some primitives and textures.
      It also renders a sprite and a pattern that has been written to serial flash.
      On top the content is warped with the VideoOut Warping Engine.
      Detects the logo mark disappearing on DISCOM and VOCA.
      No O/S is used.

1.5 Documentation
    Several documents are included in this package.
    a. this README.txt

==================
2. Release History
==================

V2.1.0s - 08-Jul-2022 [US] - 04-Jul-2022 [US] - Support for ETS board.

=================
3. Latest Changes
=================
3.1. Add new APIs. 
None.

3.2. Specification change
  - Example code: Support ETS board.

3.3. Bug fix
None.


====================
4. Known Limitations
====================

4.1 Hardware dependecy
    Runs only with this hardware:
    - Device : D1M1(H) 1.2, D1M2(H) 3.0, D1M1A 1.1, D1M1v2 2.0
    - Board  : D1x Mango Board 1.0, D1x ETS board 1.0
    - Display: any VESA-compliant PC monitor
    
4.2 RGL package 
    - Only supports GHS compiler environment version: 6.1.6 (2015-1-7)

==================
5. Additional Info
==================

5.1. Linker File
    - The included example linker file is: vlib/device/d1mx/src/rh850_ghs/d1mx.ld
     

============================================================
End of Read Me File for RENESAS GRAPHICS LIBRARY for RH850/D1M ETS Board
============================================================
