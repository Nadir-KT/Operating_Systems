#ifndef __TNT_TYPES_H__
#define __TNT_TYPES_H__

#include <stdint.h>

typedef unsigned char  INT8U;
typedef unsigned short INT16U;
typedef unsigned int   INT32U;
typedef char  INT8S;
typedef short INT16S;
typedef int   INT32S;

typedef uint8_t  u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef int8_t   s8;
typedef int16_t  s16;
typedef int32_t  s32;

#endif
