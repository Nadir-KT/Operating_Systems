#ifndef __CAN_PGW_IF_H__
#define __CAN_PGW_IF_H__

#include <cstdint>
#include "../../sack/inc/tnt_common.h"
#include "../../sack/inc/tnt_types.h"

typedef struct peerdatamsg
{
    tntMsgHdr_t msghdr;
    uint8_t          *msgptr;
    uint32_t         msglen;
    uint32_t         retries;
    uint32_t         timeoutperiod;
} peerdatamsg_t;

#endif
