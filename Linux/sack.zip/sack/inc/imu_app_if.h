#ifndef __TNT_IMU_APP_IF_H__
#define __TNT_IMU_APP_IF_H__

#include "../../sack/inc/ad_app_if.h"
#include "../../sack/inc/tnt_common.h"

#define TNT_IMU_APP_DATA_MSG_ID    TNT_FORM_MSG_ID(TNT_APP_ID, TNT_APP_MODEM_ID, TNT_APP_IMU_ID)

typedef struct tntImuData
{
    int16_t ax;
    int16_t ay;
    int16_t az;
    int16_t gx;
    int16_t gy;
    int16_t gz;
    uint8_t  ta;
    uint8_t  motion;
    uint8_t  es;
    uint8_t  pad;
    uint32_t mct;
} tntImuData_t;

typedef struct tntImuAppDataMsg
{
    tntMsgHdr_t msghdr;
    tntImuData_t imudata;
} tntImuAppDataMsg_t;

void imuSetupSysLpm(int32_t sleep_period);

#endif
