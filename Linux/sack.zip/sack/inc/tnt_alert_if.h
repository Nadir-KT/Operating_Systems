#ifndef __TNT_ALERT_IF_H__
#define __TNT_ALERT_IF_H__

#include "../../sack/inc/ad_app_if.h"
#include "../../sack/inc/tnt_common.h"

#define TNT_ALERT_APP_DATA_MSG_ID    TNT_FORM_MSG_ID(TNT_APP_ID, TNT_APP_MODEM_ID, TNT_APP_ALERT_MGR_ID)

typedef struct 
{
    char* prev_ign_state;
    char* curr_ign_state;
}IgnitionAlert;


typedef struct 
{
    char* message;
}FallAlert;

typedef struct
{
    char* message;
}AccAlert;

typedef struct 
{
    char* message;
}BatteryRemAlert;

typedef struct 
{
    u8 battery_voltage;
}LowBatteryAlert;

typedef struct 
{
    char* message;
}PanicAlert;


typedef enum {
    IGNITION_ALERT,
    FALL_ALERT,
    ACC_ALERT,
    BATTERY_REM_ALERT,
    LOW_BATTERY_ALERT,
    PANIC_ALERT
} AlertType;


typedef union {
    IgnitionAlert ignitionAlert;
    FallAlert fallAlert;
    AccAlert accAlert;
    BatteryRemAlert batteryRemAlert;
    LowBatteryAlert lowBatteryAlert;
    PanicAlert panicAlert;
} AlertData;


typedef struct tntAlertMsgData{
    tntMsgHdr_t msghdr;
    AlertType type;
    AlertData data;
} tntAlertMsgData_t;

#endif
