#ifndef __TNT_COMMON_CPY_H__
#define __TNT_COMMON_CPY_H__

#include "../../sack/inc/tnt_types.h"

/********************** MODULE IDS ******************************/
/* Each Module in TNT SW Ecosystem will have a unique ID, which
 * will be used as source or destination ID in the message headers
 * of messages exchanged between modules within the system.
 ****************************************************************/
#define TNT_APP_ID                      (0)
#define TNT_TX_DRIVER_ID                (1)
#define TNT_RX_DRIVER_ID                (2)
#define TNT_LINK_STATE_MANAGER_ID       (3)
#define TNT_TX_SCHEDULER_SMS_ID         (4)
#define TNT_TX_SCHEDULER_GPRS_ID        (5)
#define TNT_BLUETOOTH_ID                (6)
#define TNT_PERSISTENT_STORAGE_ID       (7)
#define TNT_CAN_MODULE_ID               (8)
#define TNT_IMU_MODULE_ID               (9)
#define TNT_AD_MODULE_ID                (10)
#define TNT_PGW_MODULE_ID               (11)
#define TNT_SWUPGRADE_MODULE_ID         (12)
#define TNT_SPP_GW_MODULE_ID            (13)
#define TNT_PGW_2_MODULE_ID             (14)
#define TNT_GPS_MODULE_ID               (15)
#define TNT_ALERT_MGR_MODULE_ID         (16)


/********************* Message Header *************************/
/* Every Message exchanged between modules will start with a 
 * message header. This Header will occpy 16 bytes of memory.
 * It will contain:
 *  - MessageId has the following structure
 *  ------------------------------------------------------------
 *  |            |  MSG TYPE    |  DEST ID     |   SRC ID      |
 *  ------------------------------------------------------------
 *  <---Unused--><--- 8 bits---><----8 bits----><-----8 bits--->
 *  
 *  SRC ID : 8 bit field containing module id of module sending
 *           message
 *  DEST ID: 8 bit field containing module id of module receiving
 *           message
 *  MSG TYPE : 8 bit field identifying the message between two 
 *           modules
 *
 *  8 bits of unused pad
 *
 *  - Length : Length of the payload starting after message header
 *
 *  - Pad : 8 bytes of pad reserved for future usage
 **************************************************************/
typedef struct tntMsgHdr
{
    uint32_t msgid;
    uint32_t length;
    uint32_t pad[2];
} tntMsgHdr_t;

#define TNT_FORM_MSG_ID(src,dest,type) (src | dest << 8 | type << 16)

/********************* Message Types ***************************/
/* All the messages in the system are defined below.
 * Each Message will have a predefined SRC module and DEST module.
 * The nomenclature for message will be 
 *          TNT_<SRC_MODULE_NAME>_<DEST_MODULE_NAME>_MSGNAME
 *
 * Each Message will have a unique value based on the source
 * and destination of the message.  
 ***************************************************************/
#define TNT_MESSAGE_TYPE_BASE                       (0)

#define TNT_APP_TD_COMMIS_DATA                      (1)
#define TNT_TS_APP_THRESHOLD_NOTI                   (2)
#define TNT_TS1_TD_MSG_SEND                         (3)
#define TNT_TD_TS1_MSG_ACK                          (4)
#define TNT_TD_APP_NW_PARAMS						(5)
#define TNT_LSM_APP_LINK_UPDATE						(6)
#define TNT_APP_TS1_MSG_POSTED                      (7)
#define TNT_RD_APP_SERVER_MSG                       (8)
#define TNT_PEER_DATA_MSG                           (9)
#define TNT_AD_APP_PANIC_MSG                        (11)
#define TNT_IMU_APP_DATA_MSG                        (12)
#define TNT_APP_PEER_SW_VER_REQ                     (13)
#define TNT_APP_PEER_SW_VER_RSP                     (14)
#define TNT_APP_PEER_START_MSG                      (15)
#define TNT_APP_PEER_SW_DL_REQ                      (16)
#define TNT_APP_PEER_SW_DL_RSP                      (17)
#define TNT_APP_PEER_SW_DL_PKT                      (18)
#define TNT_APP_PEER_SW_DL_ACKNACK                  (19)
#define TNT_APP_PEER_SW_DL_COMPLETE                 (20)
#define TNT_AD_APP_GPIO_MEAS                        (21)
#define TNT_APP_SWU_UPGRADE_REQ                     (22)
#define TNT_PEER_ALIVE_POLL                         (23)
#define TNT_SWU_TD_FTP_START                        (24)
#define TNT_SWU_TD_FTP_END                          (25)
#define TNT_APP_PEER_SW_DL_COMPLETE_ACK             (26)
#define TNT_APP_PEER_RESET_REQ                      (27)
#define TNT_CAN_APP_OBD2_CONFIG                     (28)
#define TNT_APP_SELF_RESET_REQ                      (29)
#define TNT_APP_CAN_INFO_REQ                        (30)
#define TNT_SPP_GW_TX_MSG                           (31)
#define TNT_SPP_GW_CONN_INFO                        (32)
#define TNT_DUMMY_MSG                               (33)
#define TNT_PEER_MSG                                (34)
#define TNT_CAN_APP_FAULT_CODE                      (35)
#define TNT_AD_APP_ADXL_DATA                        (36)
#define TNT_APP_PEER_DELAYED_RESET_REQ              (37)
#define TNT_APP_PEER_START_PWR_SAVE_REQ             (38)
#define TNT_APP_PEER_EXIT_PWR_SAVE_REQ              (39)
#define TNT_AD_APP_PWR_SAVE_EXIT_ACK                (40)
#define TNT_AD_APP_PEER_DEBUG_INFO                  (41)
#define TNT_GPS_APP_CREATE_PKT_REQ                  (42)
#define TNT_APP_TD_PRIORITY_PACKET                  (43)
#define TNT_OBD_DATA_MSG                            (44)
#define TNT_APP_TD_SPACK_RECVD                      (45)
#define TNT_GPS_APP_DRV_EVENT_MSG                   (46)
#define TNT_SPP_GW_ENC_MSG                          (47)
#define TNT_PEER_IMMOB_REQ_MSG                      (48)
#define TNT_PEER_SET_TIME_MSG                       (49)
#define TNT_CAN_RESET_MSG                           (50)
#define TNT_APP_POWER_SAVE_EXIT_MSG                 (51)
#define TNT_CAN_SPEED_STATE_MSG                     (52)
#define TNT_APP_CAN_DEBUG_MSG                       (53)
#define TNT_APP_PEER_STORE_PKT                      (54)
#define TNT_APP_PEER_BUFF_INFO                      (55)
#define TNT_APP_PEER_FETCH_PKT_RESP                 (56)
#define TNT_APP_PEER_FETCH_BUFF_INFO                (57)
#define TNT_APP_PEER_FETCH_PKT                      (58)
#define TNT_APP_PEER_FORMAT_FLASH_REQ               (59)
#define TNT_CAN_APP_DEBUG_MSG                       (60)
#define TNT_APP_TD_START_NW_DATA                    (61)
#define TNT_APP_TD_STOP_NW_DATA                     (62)
#define TNT_APP_TD_START_NW                         (63)
#define TNT_APP_TD_STOP_NW                          (64)
#define TNT_APP_TD_ENTER_SLEEP_MODE                 (65)
#define TNT_APP_TD_EXIT_SLEEP_MODE                  (66)
#define TNT_CAN_APP_DATA_MSG_DM                     (67)
#define TNT_CAN_APP_DATA_MSG_CM                     (68)
#define TNT_APP_PEER_FETCH_CM_PKT                   (69)
#define TNT_APP_PEER_FETCH_DM_PKT                   (70)
#define TNT_APP_PEER_PWR_SAVE_REQ_RSP               (71)
#define TNT_APP_PEER_PWR_SAVE_REQ_RSP_ACK_ACK       (72)
#define TNT_APP_VFOTA_STATUS_MSG                    (73)
#define TNT_APP_VFOTA_FAIL_MSG                      (74)
#define TNT_APP_PEER_VFOTA_PKG_READY                (75)
#define TNT_AD_APP_FETCH_VFOTA_PARAMS               (76)
#define TNT_APP_AD_VFOTA_PARAMS                     (77)
#define TNT_AD_APP_VFOTA_COMP_DATA_FETCH            (78)
#define TNT_AD_APP_VFOTA_STATUS                     (79)
#define TNT_APP_PEER_VFOTA_DATA_DL                  (80)
#define TNT_APP_PEER_VFOTA_DL_PKT                   (81)
#define TNT_APP_VFOTA_DATA_CHUNK                    (82)
#define TNT_AD_APP_VFOTA_TCU_UPDATE                 (83)
#define TNT_MODEM_GENERIC_INFO_MSG                  (84)
#define TNT_VCU_PARAMS_MSG                          (85)
#define TNT_VCU_PARAMS_REQ_MSG                      (86)
#define TNT_APP_CAN_79D_MSG                         (87)
#define TNT_AD_APP_VFOTA_NOT_SAFE_MSG               (88)
#define TNT_AD_APP_VFOTA_SAFE_STATE_MSG             (89)
#define TNT_AD_APP_VFOTA_GET_USER_CONCENT           (90)
#define TNT_AD_APP_VFOTA_USER_CONCENT_ACK_MSG       (91)
#define TNT_AD_APP_VFOTA_USER_CONCENT_NACK_MSG      (92)
#define TNT_AD_APP_VFOTA_USER_CONCENT_NO_RESPONSE   (93)
#define TNT_AD_APP_VFOTA_DLD_IMG_DATA               (94)
#define TNT_AD_APP_VFOTA_EXE_IMG_DATA               (95)
#define TNT_AD_APP_VFOTA_DLD_IMG_DATA_ACK_MSG       (96)
#define TNT_AD_APP_VFOTA_DLD_IMG_DATA_NACK_MSG      (97)
#define TNT_AD_APP_VFOTA_DLD_IMG_DATA_NO_RESPONSE   (98)
#define TNT_AD_APP_VFOTA_EXE_IMG_DATA_ACK_MSG       (99)
#define TNT_AD_APP_VFOTA_EXE_IMG_DATA_NACK_MSG      (100)
#define TNT_AD_APP_VFOTA_EXE_IMG_DATA_NO_RESPONSE   (101)
#define TNT_AD_APP_VFOTA_PARAMS_ACK_MSG             (102)
#define TNT_PEER_79D_ACK_MSG                        (103)
#define TNT_BMS_PARAMS_MSG                          (104)
#define TNT_MCU_PARAMS_MSG                          (105)
#define TNT_APP_FETCH_ECU_PARAMS                    (106)
#define TNT_APP_PEER_SW_VER_RSP_W_MICRO             (107)

#define TNT_CAN_APP_DATA_MSG                        (122)


/********* Common Defs ************/
#define TNT_ERROR       (0)
#define TNT_FAILURE     (0)
#define TNT_SUCCESS     (1)
#define TNT_CONTINUE    (2)
#define TNT_RETRY       (3)
#define TNT_UPDATE_NOT_NEEDED (4)

/* Dummy Message for creating a vitrual timeout for tasks in M66 
 * when they are stuck on listening to their message queues
 */
#define TNT_DUMMY_MSG_ID TNT_FORM_MSG_ID(TNT_APP_ID,TNT_APP_ID,TNT_DUMMY_MSG)

void create_sw_and_hw_version(void);
#endif
