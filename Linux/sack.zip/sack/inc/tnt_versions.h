#ifndef __TNT_VERSIONS_H__
#define __TNT_VERSIONS_H__

#define SW_MI_VERSION "0.70"
#define SW_NANO_VERSION "0.02"
//#define SW_MI_VERSION "0.44"
//#define SW_NANO_VERSION "0.0A"

#endif
