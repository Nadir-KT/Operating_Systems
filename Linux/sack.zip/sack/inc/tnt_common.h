#ifndef __TNT_COMMON_H__
#define __TNT_COMMON_H__

#include "../../sack/inc/tnt_types.h"

/********************** MODULE IDS ******************************/
/* Each Module in TNT SW Ecosystem will have a unique ID, which
 * will be used as source or destination ID in the message headers
 * of messages exchanged between modules within the system.
 ****************************************************************/
#define TNT_APP_ID                      (0)
#define TNT_APP_MODEM_ID                (1)

/********************* Message Header *************************/
/* Every Message exchanged between modules will start with a 
 * message header. This Header will occpy 16 bytes of memory.
 * It will contain:
 *  - MessageId has the following structure
 *  ------------------------------------------------------------
 *  |            |  MSG TYPE    |  DEST ID     |   SRC ID      |
 *  ------------------------------------------------------------
 *  <---Unused--><--- 8 bits---><----8 bits----><-----8 bits--->
 *  
 *  SRC ID : 8 bit field containing module id of module sending
 *           message
 *  DEST ID: 8 bit field containing module id of module receiving
 *           message
 *  MSG TYPE : 8 bit field identifying the message between two 
 *           modules
 *
 *  8 bits of unused pad
 *
 *  - Length : Length of the payload starting after message header
 *
 *  - Pad : 8 bytes of pad reserved for future usage
 **************************************************************/
typedef struct tntMsgHdr
{
    uint32_t msgid;
    uint32_t length;
    uint32_t pad[2];
} tntMsgHdr_t;

#define TNT_FORM_MSG_ID(src,dest,type) (src | dest << 8 | type << 16)

/********************* Message Types ***************************/
/* All the messages in the system are defined below.
 * Each Message will have a predefined SRC module and DEST module.
 * The nomenclature for message will be 
 *          TNT_<SRC_MODULE_NAME>_<DEST_MODULE_NAME>_MSGNAME
 *
 * Each Message will have a unique value based on the source
 * and destination of the message.  
 ***************************************************************/
#define TNT_MESSAGE_TYPE_BASE                       (0)

#define TNT_APP_ALERT_MGR_ID                        (1)
#define TNT_APP_IMU_ID                              (2)

#define TNT_APP_PEER_IMEI_REQ_MSG_ID                (3)
#define TNT_APP_PEER_IMEI_RSP_MSG_ID                (4)
#define TNT_APP_PEER_SW_VER_REQ_MSG_ID              (5)
#define TNT_APP_PEER_SW_VER_RSP_MSG_ID              (6)
#define TNT_AD_APP_GPIO_MEAS                        (7)




/********* Common Defs ************/
#define TNT_ERROR       (0)
#define TNT_FAILURE     (0)
#define TNT_SUCCESS     (1)
#define TNT_CONTINUE    (2)
#define TNT_RETRY       (3)
#define TNT_UPDATE_NOT_NEEDED (4)

/* Dummy Message for creating a vitrual timeout for tasks in M66 
 * when they are stuck on listening to their message queues
 */
#define TNT_DUMMY_MSG_ID TNT_FORM_MSG_ID(TNT_APP_ID,TNT_APP_ID,TNT_DUMMY_MSG)

void create_sw_and_hw_version(void);
#endif
