#ifndef __AD_APP_IF_H__
#define __AD_APP_IF_H__

#include "../../sack/inc/tnt_common.h"
#include "../../sack/inc/tnt_versions.h"

#define MAX_IMEI_LEN (16)
#define MAX_SW_VERSION_LEN (10)

#define BUFFERED_DATA_PACKET    (0)
#define BUFFERED_CAN_PACKET     (3)


#define CHECKSUM_ACK (1)
#define CHECKSUM_NACK (0)

#define CHECKSUM_ACK_REASON_SUCCESS          (0)
#define CHECKSUM_NACK_REASON_MISMATCH        (1)
#define CHECKSUM_NACK_REASON_FILE_READ_ERROR (2)

#define TNT_AD_APP_GPIO_MEAS_MSG_ID          TNT_FORM_MSG_ID(TNT_APP_ID,TNT_APP_MODEM_ID,TNT_AD_APP_GPIO_MEAS)


typedef struct tntPeerSwVerReq
{
    tntMsgHdr_t msghdr;
} tntPeerSwVerReq_t;

typedef struct tntPeerSwVerRsp
{
    tntMsgHdr_t msghdr;
    uint8_t          swversion[10];
} tntPeerSwVerRsp_t;



typedef struct tntPeerIMEIRsp
{
    tntMsgHdr_t msghdr;
    uint8_t          imei[10];
} tntPeerIMEIRsp_t;

typedef struct tntGpioMeasMsg
{
    tntMsgHdr_t msghdr;
    uint16_t adc0;
    uint16_t adc1;
    uint16_t adcLipo;
    uint8_t  ign;
    uint8_t  panichw;
    uint8_t  lipoChgEn;
    uint8_t  lipoChgStatus;
    uint8_t  pad[2];
} tntGpioMeasMsg_t;


#endif
