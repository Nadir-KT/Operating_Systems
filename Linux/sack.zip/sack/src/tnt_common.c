#include <string.h>
#include <stdlib.h>
#include "tnt_types.h"
//#include "tnt_common.h"
//#include "ad_app_if.h"

#ifdef STM32
extern char TNT_SW_VERSION[8+1];
#endif

//uint8_t tcu_sw_version[SW_LENGTH];
//uint8_t tcu_hw_version[HW_LENGTH];

/*void create_sw_and_hw_version(void)
{
    char arr[3];

    memset(arr,0,sizeof(arr));
    u8 sw_ver_major = 0;
    u8 sw_ver_minor = 0;
    u8 sw_ver_micro = 0;
    
    memcpy(arr,TNT_SW_VERSION,2);
    sw_ver_major = strtoul(arr,NULL,16);
    memcpy(arr,TNT_SW_VERSION+2,2);
    sw_ver_minor = strtoul(arr,NULL,16);
    memcpy(arr,SW_MI_VERSION+2,2);
    sw_ver_micro = strtoul(arr,NULL,16);

    tcu_sw_version[0] = TCU_VEH_CATEGORY;
    tcu_sw_version[1] = TCU_SW_PART_NUM_0;
    tcu_sw_version[2] = TCU_SW_PART_NUM_1;
    tcu_sw_version[3] = TCU_SW_PART_NUM_2;
    tcu_sw_version[4] = TCU_SW_PART_NUM_3;
    tcu_sw_version[5] = TCU_SW_PART_NUM_4;
    tcu_sw_version[6] = TCU_SKU_NO_0;
    tcu_sw_version[7] = TCU_SKU_NO_1;
    tcu_sw_version[8] = TCU_SKU_NO_2;
    tcu_sw_version[9] = TCU_APP_SW_TYPE;
    tcu_sw_version[10] = TCU_COMP;
    tcu_sw_version[11] = sw_ver_major;
    tcu_sw_version[12] = sw_ver_minor;
    tcu_sw_version[13] = sw_ver_micro;
    tcu_sw_version[14] = TCU_REL_CAT;
    tcu_sw_version[15] = 0;
    tcu_sw_version[16] = 0;
    tcu_sw_version[17] = 0;

    tcu_hw_version[0] = TCU_HW_PART_NUM_0;
    tcu_hw_version[1] = TCU_HW_PART_NUM_1;
    tcu_hw_version[2] = TCU_HW_PART_NUM_2;
    tcu_hw_version[3] = TCU_HW_PART_NUM_3;
    tcu_hw_version[4] = TCU_HW_PART_NUM_4;
    tcu_hw_version[5] = TCU_SKU_NO_0;
    tcu_hw_version[6] = TCU_SKU_NO_1;
    tcu_hw_version[7] = TCU_SKU_NO_2;
    tcu_hw_version[8] = TCU_COMP;
    tcu_hw_version[9] = 0x01;
    tcu_hw_version[10] = 0;
    tcu_hw_version[11] = 0x01;
    tcu_hw_version[12] = 0;
    tcu_hw_version[13] = 0;
    tcu_hw_version[14] = 0;
}*/
